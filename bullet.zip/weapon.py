import abc


class Weapon:
    __metaclass__ = abc.ABCMeta

    @abc.abstractmethod
    def __init__(self, damage, magazine):
        self.damage = damage
        self.magazine = dict([("MAX", magazine), ("curent", magazine)])
        self.shoot_cooldown = 0
        self.reload_cooldown = 0
        self.bullet_class = ""

